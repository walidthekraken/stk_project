PROJECT MADE BY: AZIZI WALID and KEBIR AHMED RAYANE / DAC 

1. Please move the notebooks out of the unzipped folder
2. Please move the report out of the unzipped folder
3. Buffers were removed from git and the submission because of the size (a few gigs)
4. The notebooks contain all explored concepts, evaluations and strategies.
5. All trained agents are under 'trained_agents' folder.